"""Unicode Properties from Unicode version 15.1.0 (autogen)."""
